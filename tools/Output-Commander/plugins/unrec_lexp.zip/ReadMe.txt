Unrecorded List Exporter

-Plugin f�r Output-Commander 2.0
 Exportiert die Liste der noch nicht aufgenommenen Outputs
 in eine GOF-Datei.

-Plugin for Output-Commander 2.0
 Exports the not yet recorded outputs to a GOF file.

(C) Lubo (Jannik Luboeinski) 8th and 10th December 2006