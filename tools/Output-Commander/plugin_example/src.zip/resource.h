///////////////////////////////////////////////////////////
///////////////////
///////// OUTPUT-COMMANDER 2.0 RESSOURCENDEFINITIONEN
///////// (C) Lubo (Jannik Luboeinski) 2006
///////////////////
///////////////////////////////////////////////////////////

/* Russisch-Unterst�tzung */
#ifndef DEV_CPP
#define RUSSIAN_SUPPORTED
#endif

/* Sprachen */
#define DE                                0
#define EN                               43
#ifdef RUSSIAN_SUPPORTED
#define RU                               86
#endif

/* Version */
#define MAJOR                             2
#define MINOR                             0
#define VER                           "2.0"

/* Symbole */
#define IDI_ICON						  1
#define IDI_ICONFILE					  2

/* Bitmaps */
#define IDB_GERMAN                      101
#define IDB_ENGLISH                     102
#define IDB_RUSSIAN                     103
#define IDB_GOF                         104

/* Accelators */
#define IDA_KEYS                        105

/* Men� Hauptfenster */
#define IDM_CSLLOAD                     106
#define IDM_SVM                         107
#define IDM_REC                         108
#define IDM_TXTSAVE                     109
#define IDM_FILE                        110
#define IDM_INFO                        111
#define IDM_OPTIONS                     112
#define IDM_SEARCH                      113
#define IDM_EXIT                        114
#define IDM_WINSNDREC                   115
#define IDM_UDEFPROG                    116
#define IDM_GOFSAVE                     117
#define IDM_TXTSAVE2                    118
#define IDM_REFRESH                     119
#define IDM_LABELIMPORT                 120
#define IDM_LABELEXPORT                 121

/* IDs Hauptfenster */
#define IDC_PLAYSTOP                    122
#define IDC_LABEL1						123
#define IDC_LABEL2						124
#define IDC_OUTPUT				     	125
#define IDC_STATIC4 					126
#define IDC_LIST                        127
#define IDC_LIST2                       128
#define IDC_LIST3                       129
#define IDC_SORT                        130 
#define IDC_LABEL3                      131
#define IDC_LABEL4                      132
#define IDC_LABEL5                      133
#define IDC_SRC                         134
#define IDC_RECORD                      135
#define IDC_PLAY                        136
#define IDC_SPELOAD                     137
#define IDC_GERMAN                      138
#define IDC_ENGLISH                     139
#define IDC_RUSSIAN                     140
#define IDC_GOFSUPPORT                  141

/* Dateiinfo-Dialog */
#define IDC_INFO_OK                     142
#define IDC_NAME                        143
#define IDC_FATH                        144
#define IDC_AUTH                        145
#define IDC_DATE                        146
#define IDC_CODE                        147
#define IDC_STATIC                      148
#define IDC_OUTS                        149
#define IDC_DEL                         150
#define IDC_FSIZ                        151

/* Optionen-Dialog */
#define IDC_PATH                        152
#define IDC_SAVESET                     153
#define IDC_CLOSEOPT                    154
#define IDC_PATH_OPEN                   155
#define IDC_PATH_CHOOSE                 156
#define IDC_IDTEXT                      157
#define IDC_ID2TEXT                     158
#define IDC_ID3TEXT                     159
#define IDC_PATH_CHOOSE2                160
#define IDC_PATH2                       161
#define IDC_EMPTYWAV                    162
#define IDC_AUTOREFRESH                 163

/* Suchen-Dialog */
#define IDC_RADIO1                      164
#define IDC_RADIO2                      165
#define IDC_SEAR_OK                     166
#define IDC_STEXT                       167
#define IDC_RADIO3                      168
#define IDC_SEAR_CL                     169
#define IDC_CAPSMALL                    170

/* Sprachspezifisch */
#define IDD_SEAR_DE                     171
#define IDD_OPTIONS_DE                  172
#define IDD_INFO_DE                     173
#define IDM_MENU_DE                     174
#define IDD_SEAR_EN                     175
#define IDD_OPTIONS_EN                  176
#define IDD_INFO_EN                     177
#define IDM_MENU_EN                     178
#define IDD_SEAR_RU                     179
#define IDD_OPTIONS_RU                  180
#define IDD_INFO_RU                     181
#define IDM_MENU_RU                     182

/* Strings */
#define IDS_TITLE                       183
#define IDS_CLASS                       184
#define IDS_MSG1                        185
#define IDS_MSG2                        186
#define IDS_MSG3                        187
#define IDS_MSG4                        188
#define IDS_MSG5                        189
#define IDS_MSG6                        190
#define IDS_MSG7                        191
#define IDS_MSG8                        192
#define IDS_MSG9                        193
#define IDS_MSG10                       194
#define IDS_MSG11                       195
#define IDS_MSG12                       196
#define IDS_MSG13                       197
#define IDS_MSG14                       198
#define IDS_MSG15                       199
#define IDS_MSG16                       200
#define IDS_MSG17                       201
#define IDS_MSG18                       202
#define IDS_MSG19                       203
#define IDS_MSG20                       204
#define IDS_MSG21                       205
#define IDS_MSG22                       206
#define IDS_MSG23                       207
#define IDS_MSG24                       208
#define IDS_MSG25                       209
#define IDS_MSG26                       210
#define IDS_MSG27                       211
#define IDS_MSG28                       212
#define IDS_MSG29                       213
#define IDS_MSG30                       214
#define IDS_MSG31                       215
#define IDS_MSG32                       216
#define IDS_MSG33                       217
#define IDS_MSG34                       218
#define IDS_MSG35                       219
#define IDS_MSG36                       220
#define IDS_MSG37                       221
#define IDS_MSG38                       222
#define IDS_MSG39                       223
#define IDS_MSG40                       224
#define IDS_MSG41                       225
#define IDS_MSG42                       226
#define IDS_MSG43                       227

/* Basiswert f�r Men�erweiterungen */
#ifdef RUSSIAN_SUPPORTED
#define IDM_EXTENT                      314
#else
#define IDM_EXTENT                      271
#endif
