///////////////////////////////////////////////////////////
///////////////////
///////// OUTPUT-COMMANDER 2.0 GLOBALVARIABLEN
///////// (C) Lubo (Jannik Luboeinski) 2006
///////////////////
///////// Bei entspr. Variablen steht der Arraytyp 
///////// vom Originalprogramm dahinter
///////////////////
///////////////////////////////////////////////////////////

#ifdef MAXFILENAME
#undef MAXFILENAME
#warning Eine �ltere Definition von MAXFILENAME wurde �berschrieben.
#endif
#ifdef MAXVIDDIGITS
#undef MAXVIDDIGITS
#warning Eine �ltere Definition von MAXVIDDIGITS wurde �berschrieben.
#endif
#ifdef MAXLINE
#undef MAXLINE
#warning Eine �ltere Definition von MAXLINE wurde �berschrieben.
#endif
#define MAXFILENAME 0x40
#define MAXVIDDIGITS 10
#define MAXLINE 10000

typedef struct {
  int Name;
  int VoiceID;
  int Guild;
  int Number;
  int ID;
} INFOSTRUCT;

typedef struct {
  char sndfil [MAXFILENAME];
} SOUNDFILE;

typedef struct {
  char npc [MAXFILENAME];
  char voice [MAXVIDDIGITS];
} SPEAKER;

typedef struct {
  char name [MAXFILENAME];
  char extension [MAXFILENAME];
  char format [MAXLINE];
  int npc;
  int outputid;
  int file;
  int voice;
  int outputtext;
} PLUGIN;

typedef struct {
  char Name [MAXFILENAME];
  char Module [MAX_PATH];
  HMODULE hLib;
  BOOL GetMessages;
  BOOL CreateMenuEntry;
} DLLPLUGIN;

/* Statusvariablen */
int *recstate;
int *Loading;
int *ExtActive;
BOOL *DejaLoad;
int *SORTMODE;
int *CreateWavFile;
int *AutoRefresh;
int *Language;
int *lSearch;
int *MenuExtP;
int *PlugCount;

/* Pfade */
char* speechpath;
char* recpath;
char* arg;
      
/* Strukturinformationen */
INFOSTRUCT *info;
INFOSTRUCT *dia;
INFOSTRUCT *dial;
char *StrucDia, *StrucInfo, *StrucDial;

/* Allgemeine Anwendungshandles */
HWND* Main_Dia;
HINSTANCE* hInstGlob;

/* Control-hWnds */
HWND* OUList;
HWND* chButton;
HWND* OUList2;
HWND* OUList3;
HWND* hLabel1;
HWND* hLabel3;
HWND* hLabel4;
HWND* hLabel1C;
HWND* hLabel3C;
HWND* hLabel4C;
HWND* hPlFile;
HWND* hPlFile2;
HWND* hRecButton;
HWND* hSearchText;
HWND* hProgress;
HWND* hGerman;
HWND* hEnglish;
HWND* hRussian;
HWND* hGofSupport;
HWND* spPath;
HWND* recPath;
HWND* hOutput;
HWND* hOutputC;
HWND* hDelete;
HWND* extDia;
HWND* extIDTextA;
HWND* extIDTextB;
HWND* extIDTextC;
HWND* hCapSmall;
HWND* hCWavFile;
HWND* hAutoRefresh;
HWND* sOk;
HWND* sRadioA;
HWND* sRadioB;
HWND* sRadioC;
HWND* sText;
HWND* iSize;
HWND* iName;
HWND* iPfad;
HWND* iAuth;
HWND* iDate;
HWND* iCode;
HWND* iOuts;

/* Schriftart */
HFONT* litFont;

/* Bitmap-Handles */
HBITMAP* hBGerman;
HBITMAP* hBEnglish;
HBITMAP* hBRussian;
HBITMAP* hBGof;

/* Men�-Handle */
HMENU* hMenu;

/* Accelator-Handle */
HACCEL* hAccel;

/* Dateiinfo-Variablen */
char* outs; //char[200]
char* auth;
char* date;
char* fsize; //char[200]

/* CommonDialog */
char *FileName; //char[MAX_PATH]
char *TitleName; //char[MAX_PATH]
char *FileNameSave; //char[MAX_PATH]
OPENFILENAME *ofn;

/* Mehrdimensionale Datenarrays */
SOUNDFILE *files; //SOUNDFILE[MAXCOUNT]
char **outputs; //char[MAXCOUNT][MAXOUTPUT]
SPEAKER *spkr; //SPEAKER[MAXCOUNT]
int *list2c; //int[MAXCOUNT]
int *list3c; //int[MAXCOUNT]
PLUGIN *plugins; //PLUGIN[MAXPLUG]
DLLPLUGIN *dplugs; //DLLPLUGIN[MAXPLUG]
