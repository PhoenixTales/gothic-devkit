#include <windows.h>
#include "ouc_globals.h"
#include "resource.h"

#define OUC_VERSION_MAJOR 2
#define OUC_VERSION_MINOR 0

#define MENU_ID 1001

const char NAME [] = "Beispiel-Plugin";

void CreateVarFromArray(void** ar)
{
  recstate = (int*)ar[0];
  Loading = (int*)ar[1];
  ExtActive = (int*)ar[2];
  DejaLoad = (int*)ar[3];
  SORTMODE = (int*)ar[4];
  CreateWavFile = (int*)ar[5];
  AutoRefresh = (int*)ar[6];
  Language = (int*)ar[7];
  lSearch = (int*)ar[8];
  MenuExtP = (int*)ar[9];
  PlugCount = (int*)ar[10];
  speechpath = (char*)ar[11];
  recpath = (char*)ar[12];
  arg = (char*)ar[13];
  info = (INFOSTRUCT*)ar[14];
  dia = (INFOSTRUCT*)ar[15];
  dial = (INFOSTRUCT*)ar[16];
  StrucDia = (char*)ar[17];
  StrucInfo = (char*)ar[18];
  StrucDial = (char*)ar[19];
  Main_Dia = (HWND*)ar[20];
  hInstGlob = (HINSTANCE*)ar[21];
  OUList = (HWND*)ar[22];
  chButton = (HWND*)ar[23];
  OUList2 = (HWND*)ar[24];
  OUList3 = (HWND*)ar[25];
  hLabel1 = (HWND*)ar[26];
  hLabel3 = (HWND*)ar[27];
  hLabel4 = (HWND*)ar[28];
  hLabel1C = (HWND*)ar[29];
  hLabel3C = (HWND*)ar[30];
  hLabel4C = (HWND*)ar[31];
  hPlFile = (HWND*)ar[32];
  hPlFile2 = (HWND*)ar[33];
  hRecButton = (HWND*)ar[34];
  hSearchText = (HWND*)ar[35];
  hProgress = (HWND*)ar[36];
  hGerman = (HWND*)ar[37];
  hEnglish = (HWND*)ar[38];
  hRussian = (HWND*)ar[39];
  hGofSupport = (HWND*)ar[40];
  spPath = (HWND*)ar[41];
  recPath = (HWND*)ar[42];
  hOutput = (HWND*)ar[43];
  hOutputC = (HWND*)ar[44];
  hDelete = (HWND*)ar[45];
  extDia = (HWND*)ar[46];
  extIDTextA = (HWND*)ar[47];
  extIDTextB = (HWND*)ar[48];
  extIDTextC = (HWND*)ar[49];
  hCapSmall = (HWND*)ar[50];
  hCWavFile = (HWND*)ar[51];
  hAutoRefresh = (HWND*)ar[52];
  sOk = (HWND*)ar[53];
  sRadioA = (HWND*)ar[54];
  sRadioB = (HWND*)ar[55];
  sRadioC = (HWND*)ar[56];
  sText = (HWND*)ar[57];
  iSize = (HWND*)ar[58];
  iName = (HWND*)ar[59];
  iPfad = (HWND*)ar[60];
  iAuth = (HWND*)ar[61];
  iDate = (HWND*)ar[62];
  iCode = (HWND*)ar[63];
  iOuts = (HWND*)ar[64];
  litFont = (HFONT*)ar[65];
  hBGerman = (HBITMAP*)ar[66];
  hBEnglish = (HBITMAP*)ar[67];
  hBRussian = (HBITMAP*)ar[68];
  hBGof = (HBITMAP*)ar[69];
  hMenu = (HMENU*)ar[70];
  hAccel = (HACCEL*)ar[71];
  outs = (char*)ar[72];
  auth = (char*)ar[73];
  date = (char*)ar[74];
  fsize = (char*)ar[75];
  FileName = (char*)ar[76];
  TitleName = (char*)ar[77];
  FileNameSave = (char*)ar[78];
  ofn = (OPENFILENAME*)ar[79];
  files = (SOUNDFILE*)ar[80];
  outputs = (char**)ar[81];
  spkr = (SPEAKER*)ar[82];
  list2c = (int*)ar[83];
  list3c = (int*)ar[84];
  plugins = (PLUGIN*)ar[85];
  dplugs = (DLLPLUGIN*)ar[86];
}

//ruft Infomrationen �ber das Plugin ab
extern "C" __declspec(dllexport) BOOL __stdcall PluginInfo(char *Name, DWORD *Version, BOOL *CreateMenuEntry)
{
  if (LOWORD(*Version) < OUC_VERSION_MAJOR) //�berpr�fen ob die Version des Output-Commanders kompatibel ist
    return FALSE;
    
  lstrcpyA(Name, NAME);
  *Version = MAKEWPARAM(OUC_VERSION_MAJOR,OUC_VERSION_MINOR);    
  *CreateMenuEntry = TRUE;
  return TRUE; //Initialisierung war erfolgreich
}

//Start-Funktion f�r das Plugin
extern "C" __declspec(dllexport) BOOL __stdcall PluginStartup(void** GlobalVar, BOOL *GetMessages)
{
  char buf [0x80];
  *GetMessages = TRUE;
  CreateVarFromArray(GlobalVar);
  lstrcpyA(buf, "�ber ");
  lstrcatA(buf, NAME);
  InsertMenu(*hMenu, IDM_INFO, MF_BYCOMMAND | MF_STRING, MENU_ID, buf);
  return TRUE; //Start war erfolgreich
}

//das Plugin wurde im Men� aufgerufen (CreateMenuEntry muss f�r diese Funktion TRUE sein)
extern "C" __declspec(dllexport) void __stdcall PluginMain(BOOL *IsRunning)
{
  MessageBox(*Main_Dia, speechpath, "Aktueller Soundpfad", MB_ICONINFORMATION);
}

//eine Nachricht wurde an das Hauptfenster gesendet (GetMessages muss f�r diese Funktion TRUE sein)
extern "C" __declspec(dllexport) void __stdcall PluginWindowMsg(UINT *msg, WPARAM *wParam, LPARAM *lParam)
{
  if (*msg == WM_COMMAND && LOWORD(*wParam) == MENU_ID) //Menuitem MENU_ID hat eine WM_COMMAND-Nachricht erhalten
    MessageBox(*Main_Dia, "Beispiel-Plugin f�r Output-Commander 2.0\n\n"
                          "Liest den aktuellen Soundpfad aus", NAME, MB_ICONINFORMATION);  
}

//Sprache wurde ge�ndert (GetMessages muss f�r diese Funktion TRUE sein)
extern "C" __declspec(dllexport) void __stdcall PluginChangeLanguage(int Language)
{
  char buf [0x80];
  lstrcpyA(buf, "�ber ");
  lstrcatA(buf, NAME);
  InsertMenu(*hMenu, IDM_INFO, MF_BYCOMMAND | MF_STRING, MENU_ID, buf);
}

//ein String wurde aus der Resource geladen (n�tzlich f�r Sprachplugins) (GetMessages muss f�r diese Funktion TRUE sein)
extern "C" __declspec(dllexport) void __stdcall PluginLoadString(int resId, char *string)
{
}
