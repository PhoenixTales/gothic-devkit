/*++

Module Name:

    dds2ztex.c

Abstract:

    Simple DDS to ZTEX File Converter for Windows.

Author:

    Nico Bendlin <nicode@gmx.net>

Revision History:

    2005-04-25  Final/reviewed release (1.0)
    2005-04-20  First public release (alpha)

--*/

#define WIN32_LEAN_AND_MEAN
#define NONAMELESSUNION
#include <windows.h>
#include <shlwapi.h>
#include <ddraw.h>
#include "ztex.h"

/*//////////////////////////////////////////////////////////////////////////////
// Return Code
*/

#define DDS2ZTEX_ERROR_NONE   0 /* No Error                  */
#define DDS2ZTEX_ERROR_ARGS   1 /* Invalid Params / Syntax   */
#define DDS2ZTEX_ERROR_OPEN   2 /* Failed to Open Input      */
#define DDS2ZTEX_ERROR_READ   4 /* Failed to Read Input      */
#define DDS2ZTEX_ERROR_CREATE 5 /* Failed to Create Output   */
#define DDS2ZTEX_ERROR_WRITE  6 /* Failed to Write Output    */
#define DDS2ZTEX_ERROR_FORMAT 7 /* Invalid Input File Format */

/*//////////////////////////////////////////////////////////////////////////////
// Global Vars
*/

static HANDLE g_StdInput;   /* STD_INPUT_HANDLE */
static HANDLE g_StdOutput;  /* STD_OUTPUT_HANDLE */
static HANDLE g_StdError;   /* STD_ERROR_HANDLE */

static BOOL g_OptionSilent;  /* FALSE */
static BOOL g_OptionStdIn;   /* FALSE */
static BOOL g_OptionStdOut;  /* FALSE */

static BOOL g_OptionIgnorePath;  /* FALSE */
static BOOL g_OptionForceNoMip;  /* FALSE */
static DWORD g_OptionForceRSize;  /* MAXDWORD */

static BOOL g_OptionForceARGB;  /* FALSE */

static TCHAR g_DDS_Filename[MAX_PATH];
static TCHAR g_TEX_Filename[MAX_PATH+5];

/*//////////////////////////////////////////////////////////////////////////////
// Utils/Stuff
*/

#ifndef max
#define max(a, b)   (((a) > (b)) ? (a) : (b)) 
#endif

void Write( HANDLE Console, LPCTSTR Text )
{
    DWORD Written;
    if ( g_OptionSilent )
        return;
    WriteFile( Console, Text, lstrlen(Text), &Written, NULL );
};

void WriteStdOut( LPCTSTR Text )
{
    if( g_OptionStdOut )
        return;
    Write( g_StdOutput, Text );
};

void WriteStdErr( LPCTSTR Text )
{
    if ( g_OptionSilent )
        return;
    Write( g_StdError, Text );
};

void WriteVersion( void )
{
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("DDS2ZTEX Converter, Version 1.0\n") );
    WriteStdOut( TEXT("Copyright (c) 2005 Nico Bendlin\n") );
};

void WriteHelp( void )
{
    WriteVersion();
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("Usage:\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  dds2ztex [options] [ddsfile] [ztexfile]\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("Options:\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  -h --help     Show this help screen\n") );
    WriteStdOut( TEXT("  -i --stdin    Use stdin as ddsfile\n") );
    WriteStdOut( TEXT("  -o --stdout   Use stdout as ztexfile\n") );
    WriteStdOut( TEXT("  -q --shutup   Suppress all messages\n") );
    WriteStdOut( TEXT("  -v --version  Copyright and version\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  --ignore-path  Don't look for hints in path\n") );
    WriteStdOut( TEXT("  --force-nomip  Do not include lower mipmaps\n") );
    WriteStdOut( TEXT("  --force-ref:X  Use ref size of X (4 - 1024)\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  --force-argb  Convert uncommon formats (e.g. BGRA) to ARGB\n") );
    WriteStdOut( TEXT("\n") );
};

/*//////////////////////////////////////////////////////////////////////////////
// Converter
*/

BOOL IsPowerOfTwo( unsigned long x )
{
    if( x == 0)
        return FALSE;
    while( (x & 1) == 0 )
        x >>= 1;
    return ( 1 == x );
};

unsigned long GetMipMapCount( unsigned long width, unsigned long height )
{
    unsigned long x;
    unsigned long y;
    unsigned long i;

    x = width;
    y = height;
    i = 1;
    while( x >= 8 && y >= 8 )
    {
        x >>= 1;
        y >>= 1;
        i++;
    };

    return i;
};


/*FIXME: Scanline Alignment */
DWORD GetMipmapSize( unsigned long format, 
                     unsigned long width, unsigned long height,
                     unsigned long level )
{
    unsigned long x;
    unsigned long y;
    unsigned long i;

    x = max( 1, width );
    y = max( 1, height );
    for( i = 0; i < level; i++ )
    {
        if( x > 1 )
            x >>= 1;
        if( y > 1 )
            y >>= 1;
    }

    switch( format )
    {
    case ZTEXFMT_B8G8R8A8: 
    case ZTEXFMT_R8G8B8A8:
    case ZTEXFMT_A8B8G8R8:
    case ZTEXFMT_A8R8G8B8:
        return x * y * 4;
    case ZTEXFMT_B8G8R8:
    case ZTEXFMT_R8G8B8:
        return x * y * 3;
    case ZTEXFMT_A4R4G4B4:
    case ZTEXFMT_A1R5G5B5:
    case ZTEXFMT_R5G6B5:
        return x * y * 2;
    case ZTEXFMT_P8:
        return x * y;
    case ZTEXFMT_DXT1:
        return max( 1, x / 4 ) * max( 1, y / 4 ) * 8;
    case ZTEXFMT_DXT2:
    case ZTEXFMT_DXT3:
    case ZTEXFMT_DXT4:
    case ZTEXFMT_DXT5:
        return max( 1, x / 4 ) * max( 1, y / 4 ) * 16;
    default:
        return 0;
    };
};

#pragma pack(push)
#pragma pack(1)

typedef struct _DXT1_BLOCK
{
    unsigned short  color_0;
    unsigned short  color_1;
    unsigned long   texel_0;
}
DXT1_BLOCK, *LPDXT1_BLOCK;

typedef struct _DXT2_BLOCK
{
    __int64         alpha_0;
    unsigned short  color_0;
    unsigned short  color_1;
    unsigned long   texel_0;
}
DXT2_BLOCK, *LPDXT2_BLOCK,
DXT3_BLOCK, *LPDXT3_BLOCK;

#pragma pack(pop)

int ConvertDDS2ZTEX( HANDLE dds, HANDLE ztex )
{
    DWORD BytesRead;
    DWORD BytesWritten;
    DWORD DdsMagic;
    DDSURFACEDESC2 DdsHeader;
    ZTEX_FILE_HEADER ZTexHeader;
    unsigned long TexFormat;
    RGBQUAD Palette[ZTEX_PAL_ENTRIES];
    unsigned long MipmapCount;
    unsigned long MipmapLevel;
    DWORD BufferSize;
    LPBYTE Buffer;
    DWORD MipmapSize;
    LPBYTE Mipmap;
    RGBQUAD * Pixel32;
    RGBTRIPLE * Pixel24;
    BYTE ColorTemp;
    unsigned long PixelCount;
    __int64 AvgColor[4];
    unsigned long i;

    /* 'DDS ' */
    if( !ReadFile( dds, &DdsMagic, sizeof(DdsMagic), &BytesRead, NULL ) ||
        BytesRead != sizeof(DdsMagic) )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to read input (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_READ;
    };
    if( DdsMagic != MAKEFOURCC( 'D', 'D', 'S', ' ' ) )
    {
        WriteStdErr( TEXT("dds2ztex: Unsupported file format (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_FORMAT;
    };
    /* DDSURFACEDESC2 */
    if( !ReadFile( dds, &DdsHeader, sizeof(DDSURFACEDESC2), &BytesRead, NULL ) ||
        BytesRead != sizeof(DDSURFACEDESC2) )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to read input (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_READ;
    };
    #define DDS2ZTEX_REQUIRED_DDS_FLAGS (   \
        DDSD_WIDTH |                        \
        DDSD_HEIGHT |                       \
        DDSD_PIXELFORMAT |                  \
        DDSD_CAPS )
    #define DDS2ZTEX_REQUIRED_DDS_CAPS (    \
        DDSCAPS_TEXTURE )
    if( DdsHeader.dwSize != sizeof(DDSURFACEDESC2) ||
        (DdsHeader.dwFlags & DDS2ZTEX_REQUIRED_DDS_FLAGS) != DDS2ZTEX_REQUIRED_DDS_FLAGS ||
        (DdsHeader.dwFlags & DDS2ZTEX_REQUIRED_DDS_CAPS) != DDS2ZTEX_REQUIRED_DDS_CAPS ||
        DdsHeader.dwWidth <= 0 ||
        DdsHeader.dwHeight <= 0 ||
        DdsHeader.u4.ddpfPixelFormat.dwSize != sizeof(DDPIXELFORMAT) )
    {
        WriteStdErr( TEXT("dds2ztex: Unsupported file format (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_FORMAT;
    };

    /* 'ZTEX' */
    memset( &ZTexHeader, 0, sizeof(ZTexHeader) );
    ZTexHeader.Signature = ZTEX_FILE_SIGNATURE;
/*  ZTexHeader.Version = ZTEX_FILE_VERSION_0; */
    ZTexHeader.TexInfo.RefWidth = ZTexHeader.TexInfo.Width = DdsHeader.dwWidth;
    ZTexHeader.TexInfo.RefHeight = ZTexHeader.TexInfo.Height = DdsHeader.dwHeight;
    while(  ZTexHeader.TexInfo.RefWidth > g_OptionForceRSize || 
            ZTexHeader.TexInfo.RefHeight > g_OptionForceRSize )
    {
        if( ZTexHeader.TexInfo.RefWidth > 1 )
            ZTexHeader.TexInfo.RefWidth >>= 1;
        if( ZTexHeader.TexInfo.RefHeight > 1 )
            ZTexHeader.TexInfo.RefHeight >>= 1;
    };
    if( !g_OptionForceNoMip && (DdsHeader.dwFlags & DDSD_MIPMAPCOUNT) == DDSD_MIPMAPCOUNT &&
        DdsHeader.u2.dwMipMapCount > 1 )
    {
        ZTexHeader.TexInfo.MipMaps = DdsHeader.u2.dwMipMapCount;
        MipmapCount = GetMipMapCount( ZTexHeader.TexInfo.Width, ZTexHeader.TexInfo.Height );
        if( MipmapCount < DdsHeader.u2.dwMipMapCount )
            ZTexHeader.TexInfo.MipMaps = MipmapCount;
    };
    #define ZTEXFMT_UNKNOWN ((unsigned long)(0xFFFFFFFF))
    TexFormat = ZTEXFMT_UNKNOWN;
    if( DDPF_FOURCC == (DDPF_FOURCC & DdsHeader.u4.ddpfPixelFormat.dwFlags) )
    {
        switch( DdsHeader.u4.ddpfPixelFormat.dwFourCC )
        {
        case 32:  /* D3DFMT_A8B8G8R8 */
            TexFormat = ZTEXFMT_A8B8G8R8;
            break;
        case 21:  /* D3DFMT_A8R8G8B8 */
            TexFormat = ZTEXFMT_A8R8G8B8;
            break;
        case 20:  /* D3DFMT_R8G8B8 */
            TexFormat = ZTEXFMT_R8G8B8;
            break;
        case 26:  /* D3DFMT_A4R4G4B4 */
            TexFormat = ZTEXFMT_A4R4G4B4;
            break;
        case 25:  /* D3DFMT_A1R5G5B5 */
            TexFormat = ZTEXFMT_A1R5G5B5;
            break;
        case 23:  /* D3DFMT_R5G6B5 */
            TexFormat = ZTEXFMT_R5G6B5;
            break;
        case 41:                                /* D3DFMT_P8 */
        case MAKEFOURCC( 'P', '8', ' ', ' ' ):  /*HACK: The Compressonator's P8 */
            TexFormat = ZTEXFMT_P8;
            break;
        case MAKEFOURCC( 'D', 'X', 'T', '1' ):  /* D3DFMT_DXT1 */
            TexFormat = ZTEXFMT_DXT1;
            break;
        case MAKEFOURCC( 'D', 'X', 'T', '2' ):  /* D3DFMT_DXT2 */
            TexFormat = ZTEXFMT_DXT2;
            break;
        case MAKEFOURCC( 'D', 'X', 'T', '3' ):  /* D3DFMT_DXT3 */
            TexFormat = ZTEXFMT_DXT3;
            break;
        case MAKEFOURCC( 'D', 'X', 'T', '4' ):  /* D3DFMT_DXT4 */
            TexFormat = ZTEXFMT_DXT4;
            break;
        case MAKEFOURCC( 'D', 'X', 'T', '5' ):  /* D3DFMT_DXT5 */
            TexFormat = ZTEXFMT_DXT5;
            break;
        default:
            break;
        };
    };
    if( ZTEXFMT_UNKNOWN == TexFormat )
    {
        if( DDPF_PALETTEINDEXED8 == (DDPF_PALETTEINDEXED8 & DdsHeader.u4.ddpfPixelFormat.dwFlags) )
            TexFormat = ZTEXFMT_P8;
        else
        if( DDPF_RGB == (DDPF_RGB & DdsHeader.u4.ddpfPixelFormat.dwFlags) )
        {
            switch( DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount )
            {
            case 32:
                if( DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask == 0x000000FF )
                {
                    if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x0000FF00 &&
                        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x00FF0000 &&
                        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0xFF000000 )
                        TexFormat = ZTEXFMT_B8G8R8A8;
                    else
                    if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0xFF000000 &&
                        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x00FF0000 &&
                        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x0000FF00 )
                        TexFormat = ZTEXFMT_R8G8B8A8;
                }
                else
                if( DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask == 0xFF000000 )
                {
                    if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x000000FF &&
                        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x0000FF00 &&
                        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x00FF0000 )
                        TexFormat = ZTEXFMT_A8B8G8R8;
                    else
                    if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x00FF0000 &&
                        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x0000FF00 &&
                        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x000000FF )
                        TexFormat = ZTEXFMT_A8R8G8B8;
                };
                break;
            case 24:
                if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x000000FF &&
                    DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x0000FF00 &&
                    DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x00FF0000 )
                    TexFormat = ZTEXFMT_B8G8R8;
                else
                if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x00FF0000 &&
                    DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x0000FF00 &&
                    DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x000000FF )
                    TexFormat = ZTEXFMT_R8G8B8;
                break;
            case 16:
                if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        == 0x00000F00 &&
                    DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        == 0x000000F0 &&
                    DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        == 0x0000000F &&
                    DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask == 0x0000F000 )
                    TexFormat = ZTEXFMT_A4R4G4B4;
                else
                if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        == 0x00007C00 &&
                    DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        == 0x000003E0 &&
                    DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        == 0x0000001F &&
                    DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask == 0x00008000 )
                    TexFormat = ZTEXFMT_A1R5G5B5;
                else
                if( DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask == 0x0000F800 &&
                    DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask == 0x000007E0 &&
                    DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask == 0x0000001F )
                    TexFormat = ZTEXFMT_R5G6B5;
                break;
            default:
                break;
            };
        };
    };
    if( ZTEXFMT_UNKNOWN == TexFormat )
    {
        WriteStdErr( TEXT("dds2ztex: Unsupported file format (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_FORMAT;
    };
    ZTexHeader.TexInfo.Format = TexFormat;
    if( g_OptionForceARGB )
    {
        switch( TexFormat )
        {
        case ZTEXFMT_B8G8R8A8: 
        case ZTEXFMT_R8G8B8A8:
        case ZTEXFMT_A8B8G8R8:
            ZTexHeader.TexInfo.Format = ZTEXFMT_A8R8G8B8;
            break;
        case ZTEXFMT_B8G8R8:
            ZTexHeader.TexInfo.Format = ZTEXFMT_R8G8B8;
            break;
        default:
            break;
        };
    };

    /* Palette */
    if( ZTEXFMT_P8 == ZTexHeader.TexInfo.Format )
    {
        if( !ReadFile( dds, &Palette, sizeof(Palette), &BytesRead, NULL ) ||
            BytesRead != sizeof(Palette) )
        {
            WriteStdErr( TEXT("dds2ztex: Failed to read input (") );
            WriteStdErr( g_DDS_Filename );
            WriteStdErr( TEXT(").\n") );
            return DDS2ZTEX_ERROR_READ;
        };
    };

    /* Mipmaps */
    MipmapCount = max( 1, ZTexHeader.TexInfo.MipMaps );
    BufferSize = 0;
    for( MipmapLevel = 0; MipmapLevel < MipmapCount; MipmapLevel++ )
        BufferSize += GetMipmapSize( ZTexHeader.TexInfo.Format, 
            ZTexHeader.TexInfo.Width, ZTexHeader.TexInfo.Height, MipmapLevel );
    Buffer = (LPBYTE)LocalAlloc( LPTR, BufferSize );
    if( !Buffer )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to alocate memory (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_READ;
    };
    if( !ReadFile( dds, Buffer, BufferSize, &BytesRead, NULL ) ||
        BytesRead != BufferSize )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to read input (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        LocalFree( (HLOCAL)Buffer );
        return DDS2ZTEX_ERROR_READ;
    };

    /* AvgColor */
    PixelCount = ZTexHeader.TexInfo.Width * ZTexHeader.TexInfo.Height;
    for( i = 0; i < 4; i++ )
        AvgColor[i] = PixelCount / 2;  /* 0.5 (round) */
    Mipmap = Buffer;
    switch( ZTexHeader.TexInfo.Format )
    {
    case ZTEXFMT_DXT1:
        {
            LPDXT1_BLOCK block = (LPDXT1_BLOCK)Mipmap;
            for( i = 0; i < PixelCount / 16; i++ )
            {
                RGBQUAD colors[4];
                unsigned long data;
                int texel;
                colors[0].rgbBlue     = (unsigned char)(((block->color_0      ) & 0x001F) * 0x00FF / 0x001F);
                colors[0].rgbGreen    = (unsigned char)(((block->color_0 >>  5) & 0x003F) * 0x00FF / 0x003F);
                colors[0].rgbRed      = (unsigned char)(((block->color_0 >> 11)         ) * 0x00FF / 0x001F);
                colors[0].rgbReserved = 0xFF;
                colors[1].rgbBlue     = (unsigned char)(((block->color_1      ) & 0x001F) * 0x00FF / 0x001F);
                colors[1].rgbGreen    = (unsigned char)(((block->color_1 >>  5) & 0x003F) * 0x00FF / 0x003F);
                colors[1].rgbRed      = (unsigned char)(((block->color_1 >> 11)         ) * 0x00FF / 0x001F);
                colors[1].rgbReserved = 0xFF;
                if( block->color_0 > block->color_1 )
                {
                    colors[2].rgbBlue     = colors[0].rgbBlue  / 3 * 2 + colors[1].rgbBlue  / 3;
                    colors[2].rgbGreen    = colors[0].rgbGreen / 3 * 2 + colors[1].rgbGreen / 3;
                    colors[2].rgbRed      = colors[0].rgbRed   / 3 * 2 + colors[1].rgbRed   / 3;
                    colors[2].rgbReserved = 0xFF;
                    colors[3].rgbBlue     = colors[0].rgbBlue  / 3 + colors[1].rgbBlue  / 3 * 2;
                    colors[3].rgbGreen    = colors[0].rgbGreen / 3 + colors[1].rgbGreen / 3 * 2;
                    colors[3].rgbRed      = colors[0].rgbRed   / 3 + colors[1].rgbRed   / 3 * 2;
                    colors[3].rgbReserved = 0xFF;
                }
                else
                {
                    colors[2].rgbBlue     = colors[0].rgbBlue  / 2 + colors[1].rgbBlue  / 2;
                    colors[2].rgbGreen    = colors[0].rgbGreen / 2 + colors[1].rgbGreen / 2;
                    colors[2].rgbRed      = colors[0].rgbRed   / 2 + colors[1].rgbRed   / 2;
                    colors[2].rgbReserved = 0xFF;
                    colors[3].rgbBlue     =
                    colors[3].rgbGreen    =
                    colors[3].rgbRed      =
                    colors[3].rgbReserved = 0x00;
                };
                data = block->texel_0;
                for( texel = 0; texel < 16; texel++ )
                {
                    unsigned char index = (unsigned char)data & 3;
                    AvgColor[0] += colors[index].rgbBlue;
                    AvgColor[1] += colors[index].rgbGreen;
                    AvgColor[2] += colors[index].rgbRed;
                /*  AvgColor[3] += colors[index].rgbReserved;  //FIXME */
                    data >>= 2;
                };
                block++;
            };
        };
        break;
    case ZTEXFMT_DXT2:  /* FIXME (premultiplied AvgColor?) */
    case ZTEXFMT_DXT3:
        {
            LPDXT3_BLOCK block = (LPDXT3_BLOCK)Mipmap;
            for( i = 0; i < PixelCount / 16; i++ )
            {
                RGBQUAD colors[4];
                int texel;
                __int64 alpha;
                unsigned long data;
                
                alpha = block->alpha_0;
                for( texel = 0; texel < 16; texel++ )
                {
                    AvgColor[3] += (unsigned char)((unsigned short)((unsigned char)alpha & 0x0F) * 0x00FF / 0x000F);
                    alpha >>= 4;
                };
                colors[0].rgbBlue     = (unsigned char)(((block->color_0      ) & 0x001F) * 0x00FF / 0x001F);
                colors[0].rgbGreen    = (unsigned char)(((block->color_0 >>  5) & 0x003F) * 0x00FF / 0x003F);
                colors[0].rgbRed      = (unsigned char)(((block->color_0 >> 11)         ) * 0x00FF / 0x001F);
                colors[1].rgbBlue     = (unsigned char)(((block->color_1      ) & 0x001F) * 0x00FF / 0x001F);
                colors[1].rgbGreen    = (unsigned char)(((block->color_1 >>  5) & 0x003F) * 0x00FF / 0x003F);
                colors[1].rgbRed      = (unsigned char)(((block->color_1 >> 11)         ) * 0x00FF / 0x001F);
                colors[2].rgbBlue     = colors[0].rgbBlue  / 3 * 2 + colors[1].rgbBlue  / 3;
                colors[2].rgbGreen    = colors[0].rgbGreen / 3 * 2 + colors[1].rgbGreen / 3;
                colors[2].rgbRed      = colors[0].rgbRed   / 3 * 2 + colors[1].rgbRed   / 3;
                colors[3].rgbBlue     = colors[0].rgbBlue  / 3 + colors[1].rgbBlue  / 3 * 2;
                colors[3].rgbGreen    = colors[0].rgbGreen / 3 + colors[1].rgbGreen / 3 * 2;
                colors[3].rgbRed      = colors[0].rgbRed   / 3 + colors[1].rgbRed   / 3 * 2;
                data = block->texel_0;
                for( texel = 0; texel < 16; texel++ )
                {
                    unsigned char index = (unsigned char)data & 3;
                    AvgColor[0] += colors[index].rgbBlue;
                    AvgColor[1] += colors[index].rgbGreen;
                    AvgColor[2] += colors[index].rgbRed;
                    data >>= 2;
                };
                block++;
            };
        };
        break;
    default:
        break;
    };
    for( i = 0; i < 4; i++ )
        AvgColor[i] /= PixelCount;
    ZTexHeader.TexInfo.AvgColor = MAKEFOURCC( AvgColor[0], AvgColor[1], AvgColor[2], AvgColor[3] );

    /* FIXME */
    if( ZTexHeader.TexInfo.MipMaps < 1 )
        ZTexHeader.TexInfo.MipMaps = 1;

    /* ZTEX_FILE_HEADER */
    if( !WriteFile( ztex, &ZTexHeader, sizeof(ZTexHeader), &BytesWritten, NULL ) ||
        BytesWritten != sizeof(ZTexHeader) )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to write output (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        LocalFree( (HLOCAL)Buffer );
        return DDS2ZTEX_ERROR_WRITE;
    };

    /* Palette */
    if( ZTEXFMT_P8 == ZTexHeader.TexInfo.Format )
    {
        for( i = 0; i < ZTEX_PAL_ENTRIES; i++ )
        {
            if( !WriteFile( ztex, &Palette[i], sizeof(ZTEX_PAL_ENTRY), &BytesWritten, NULL ) ||
                BytesWritten != sizeof(ZTEX_PAL_ENTRY) )
            {
                WriteStdErr( TEXT("dds2ztex: Failed to write output (") );
                WriteStdErr( g_TEX_Filename );
                WriteStdErr( TEXT(").\n") );
                LocalFree( (HLOCAL)Buffer );
                return DDS2ZTEX_ERROR_WRITE;
            };
        }
    };
    
    /* Mipmaps */
    Mipmap = Buffer + BufferSize;
    MipmapLevel = MipmapCount;
    while( MipmapLevel )
    {
        MipmapLevel--;
        MipmapSize = GetMipmapSize( ZTexHeader.TexInfo.Format, 
            ZTexHeader.TexInfo.Width, ZTexHeader.TexInfo.Height, MipmapLevel );
        Mipmap -= MipmapSize;

        if( g_OptionForceARGB )
        {
            Pixel32 = (RGBQUAD *)Mipmap;
            Pixel24 = (RGBTRIPLE *)Mipmap;
            switch( TexFormat )
            {
            case ZTEXFMT_B8G8R8A8:
                for( i = 0; i < MipmapSize / 4; i++ )
                {
                    ColorTemp            = Pixel32->rgbReserved;
                    Pixel32->rgbReserved = Pixel32->rgbBlue;
                    Pixel32->rgbBlue     = ColorTemp;
                    ColorTemp            = Pixel32->rgbRed;
                    Pixel32->rgbRed      = Pixel32->rgbGreen;
                    Pixel32->rgbGreen    = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_R8G8B8A8:
                for( i = 0; i < MipmapSize / 4; i++ )
                {
                    ColorTemp            = Pixel32->rgbBlue;
                    Pixel32->rgbBlue     = Pixel32->rgbGreen;
                    Pixel32->rgbGreen    = Pixel32->rgbRed;
                    Pixel32->rgbRed      = Pixel32->rgbReserved;
                    Pixel32->rgbReserved = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_A8B8G8R8:
                for( i = 0; i < MipmapSize / 4; i++ )
                {
                    ColorTemp        = Pixel32->rgbBlue;
                    Pixel32->rgbBlue = Pixel32->rgbRed;
                    Pixel32->rgbRed  = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_B8G8R8:
                for( i = 0; i < MipmapSize / 3; i++ )
                {
                    ColorTemp         = Pixel24->rgbtBlue;
                    Pixel24->rgbtBlue = Pixel24->rgbtRed;
                    Pixel24->rgbtRed  = ColorTemp;
                    Pixel24++;
                };
                break;
            default:
                break;
            };
        };

        if( !WriteFile( ztex, Mipmap, MipmapSize, &BytesWritten, NULL ) ||
            BytesWritten != MipmapSize )
        {
            WriteStdErr( TEXT("dds2ztex: Failed to write output (") );
            WriteStdErr( g_DDS_Filename );
            WriteStdErr( TEXT(").\n") );
            LocalFree( (HLOCAL)Buffer );
            return DDS2ZTEX_ERROR_WRITE;
        };
    };
    LocalFree( (HLOCAL)Buffer );

    return DDS2ZTEX_ERROR_NONE;
};

/*//////////////////////////////////////////////////////////////////////////////
// Entry Point
*/

int __cdecl main( int argc, LPTSTR argv[ ] )
{
    int i;
    int len;
    TCHAR foo[2];
    LPTSTR opt;
    HANDLE dds;
    HANDLE ztex;
    int result;

    g_StdInput = GetStdHandle( STD_INPUT_HANDLE );
    g_StdOutput = GetStdHandle( STD_OUTPUT_HANDLE );
    g_StdError = GetStdHandle( STD_ERROR_HANDLE );
    if( argc <= 0 )
    {
        WriteHelp();
        return DDS2ZTEX_ERROR_NONE;
    }
    g_OptionSilent = FALSE;
    g_OptionStdIn  = FALSE;
    g_OptionStdOut = FALSE;
    g_OptionIgnorePath = FALSE;
    g_OptionForceNoMip = FALSE;
    g_OptionForceRSize = MAXDWORD;
    g_OptionForceARGB = FALSE;
    memset( &g_DDS_Filename, 0, sizeof(g_DDS_Filename) );
    memset( &g_TEX_Filename, 0, sizeof(g_TEX_Filename) );
    for( i = 0; i < argc; i++ )
    {
        opt = argv[i];
        if( !opt || !*opt || ( *opt != '-' && *opt != '/' ) )
            break;
        if( !lstrcmpi( opt, TEXT("--") ) )
        {
            i++;
            break;
        }
        opt++;
        if( '-' == *opt )
        {
            opt++;
            if( !lstrcmpi( opt, TEXT("help") ) )
            {
                WriteHelp();
                return DDS2ZTEX_ERROR_NONE;
            }
            if( !lstrcmpi( opt, TEXT("version") ) )
            {
                WriteVersion();
                return DDS2ZTEX_ERROR_NONE;
            }
            if( !lstrcmpi( opt, TEXT("stdin") ) )
                g_OptionStdIn = TRUE;
            else if( !lstrcmpi( opt, TEXT("stdout") ) )
                g_OptionStdOut = TRUE;
            else if( !lstrcmpi( opt, TEXT("shutup") ) )
                g_OptionSilent = TRUE;
            else if( !lstrcmpi( opt, TEXT("ignore-path") ) )
                g_OptionIgnorePath = TRUE;
            else if( !lstrcmpi( opt, TEXT("force-nomip") ) )
                g_OptionForceNoMip = TRUE;
            else if( !lstrcmpi( opt, TEXT("force-ref:4") ) )
                g_OptionForceRSize = 4;
            else if( !lstrcmpi( opt, TEXT("force-ref:8") ) )
                g_OptionForceRSize = 8;
            else if( !lstrcmpi( opt, TEXT("force-ref:16") ) )
                g_OptionForceRSize = 16;
            else if( !lstrcmpi( opt, TEXT("force-ref:32") ) )
                g_OptionForceRSize = 32;
            else if( !lstrcmpi( opt, TEXT("force-ref:64") ) )
                g_OptionForceRSize = 64;
            else if( !lstrcmpi( opt, TEXT("force-ref:128") ) )
                g_OptionForceRSize = 128;
            else if( !lstrcmpi( opt, TEXT("force-ref:256") ) )
                g_OptionForceRSize = 256;
            else if( !lstrcmpi( opt, TEXT("force-ref:512") ) )
                g_OptionForceRSize = 512;
            else if( !lstrcmpi( opt, TEXT("force-ref:1024") ) )
                g_OptionForceRSize = 1024;
            else if( !lstrcmpi( opt, TEXT("force-argb") ) )
                g_OptionForceARGB = TRUE;
            else
            {
                WriteStdErr( TEXT("dds2ztex: Invalid option (") );
                WriteStdErr( argv[i] );
                WriteStdErr( TEXT(").\n") );
                return DDS2ZTEX_ERROR_ARGS;
            }
        }
        else
        {
            while( *opt )
            {
                switch( *opt )
                {
                case 'i':
                    g_OptionStdIn = TRUE;
                    break;
                case 'o':
                    g_OptionStdOut = TRUE;
                    break;
                case 'q':
                    g_OptionSilent = TRUE;
                    break;
                case 'h':
                case 'H':
                case '?':
                    WriteHelp();
                    return DDS2ZTEX_ERROR_NONE;
                case 'v':
                case 'V':
                    WriteVersion();
                    return DDS2ZTEX_ERROR_NONE;
                default:
                    WriteStdErr( TEXT("dds2ztex: Invalid option (") );
                    foo[0] = *opt;
                    foo[1] = '\0';
                    WriteStdErr( foo );
                    WriteStdErr( TEXT(").\n") );
                    return DDS2ZTEX_ERROR_ARGS;
                };
                opt++;
            };
        };
    };

    if( g_OptionStdIn )
    {
        if( g_OptionStdOut )
        {
            if( i < argc )
            {
                WriteStdErr( TEXT("dds2ztex: Too many arguments (") );
                while( i < argc )
                {
                    WriteStdErr( argv[ i ] );
                    i++;
                    if( i < argc )
                        WriteStdErr( TEXT(" ") );
                };
                WriteStdErr( TEXT(").\n") );
                return DDS2ZTEX_ERROR_ARGS;
            };
        }
        else
        {
            if( i >= argc )
            {
                WriteStdErr( TEXT("dds2ztex: Missing argument (ztexfile).\n") );
                return DDS2ZTEX_ERROR_ARGS;
            };
            lstrcpyn( g_TEX_Filename, argv[i], MAX_PATH );
        };
    }
    else
    {
        if( i >= argc )
        {
            WriteStdErr( TEXT("dds2ztex: Missing argument (ddsfile).\n") );
            return DDS2ZTEX_ERROR_ARGS;
        };
        lstrcpyn( g_DDS_Filename, argv[i], MAX_PATH );
        i++;
        if( !g_OptionStdOut && (i < argc) )
        {
            lstrcpyn( g_TEX_Filename, argv[i], MAX_PATH );
            i++;
        }
        else
        {
            lstrcpyn( g_TEX_Filename, g_DDS_Filename, MAX_PATH );
            len = lstrlen( g_TEX_Filename );
            if( len > 6 && !lstrcmpi( &g_TEX_Filename[ len - 6 ], TEXT("-C.DDS") ) )
                lstrcpyn( &g_TEX_Filename[ len - 6 ], TEXT("-C.TEX"), 7 );
            else if( len > 4 && !lstrcmpi( &g_TEX_Filename[ len - 4 ], TEXT(".DDS") ) )
                lstrcpyn( &g_TEX_Filename[ len - 4 ], TEXT("-C.TEX"), 7 );
            else
                lstrcpyn( &g_TEX_Filename[ len ], TEXT(".TEX"), 5 );
        };
        if( i < argc )
        {
            WriteStdErr( TEXT("dds2ztex: Too many arguments.\n") );
            return DDS2ZTEX_ERROR_ARGS;
        };
    };

    if( g_OptionStdIn )
    {
        lstrcpyn( g_DDS_Filename, TEXT("stdin"), MAX_PATH );
        dds = g_StdInput;
    }
    else
        dds = CreateFile( g_DDS_Filename, GENERIC_READ, FILE_SHARE_READ, NULL,
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
    if( !dds || (INVALID_HANDLE_VALUE == dds) )
    {
        WriteStdErr( TEXT("dds2ztex: Failed to open (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_OPEN;
    }
    if( g_OptionStdOut )
    {
        lstrcpyn( g_TEX_Filename, TEXT("stdout"), MAX_PATH );
        ztex = g_StdOutput;
    }
    else
        ztex = CreateFile( g_TEX_Filename, GENERIC_WRITE, FILE_SHARE_READ, NULL,
            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
    if( !ztex || (INVALID_HANDLE_VALUE == ztex) )
    {
        if( !g_OptionStdIn )
            CloseHandle(dds);
        WriteStdErr( TEXT("dds2ztex: Failed to create (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        return DDS2ZTEX_ERROR_CREATE;
    }

    if( !g_OptionIgnorePath )
    {
        TCHAR path[MAX_PATH];
        LPTSTR pos;
        lstrcpyn( path, g_DDS_Filename, MAX_PATH );
        pos = &path[ lstrlen(path) ];
        while( pos > path )
        {
            if( *pos == '\\' || *pos == '/' )
            {
                *pos = '\0';
                break;
            };
            pos--;
        };
        if( !g_OptionForceNoMip )
        {
            if( StrStrI( path, TEXT("NOMIP") ) )
                g_OptionForceNoMip = TRUE;
        };
        if( g_OptionForceRSize == MAXDWORD )
        {
            if( StrStrI( path, TEXT("\\4") ) )
                g_OptionForceRSize = 4;
            else
            if( StrStrI( path, TEXT("\\8") ) )
                g_OptionForceRSize = 8;
            else
            if( StrStrI( path, TEXT("\\16") ) )
                g_OptionForceRSize = 16;
            else
            if( StrStrI( path, TEXT("\\32") ) )
                g_OptionForceRSize = 32;
            else
            if( StrStrI( path, TEXT("\\64") ) )
                g_OptionForceRSize = 64;
            else
            if( StrStrI( path, TEXT("\\128") ) )
                g_OptionForceRSize = 128;
            else
            if( StrStrI( path, TEXT("\\256") ) )
                g_OptionForceRSize = 256;
            else
            if( StrStrI( path, TEXT("\\512") ) )
                g_OptionForceRSize = 512;
            else
            if( StrStrI( path, TEXT("\\1024") ) )
                g_OptionForceRSize = 1024;
        };
    };
    
    result = ConvertDDS2ZTEX( dds, ztex );

    if( !g_OptionStdIn )
        CloseHandle( dds );
    if( !g_OptionStdOut )
    {
        CloseHandle( ztex );
        if( result != DDS2ZTEX_ERROR_NONE )
            DeleteFile( g_TEX_Filename );
    }

    return result;
};

int __stdcall xWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
    #define MAX_ARGUMENTS ( 0x100 )

    int argc;
    int result;
    BOOL quote;
    SIZE_T size;
    LPTSTR argv[ MAX_ARGUMENTS+1 ];
    LPTSTR CmdLine;
    LPTSTR Command;

    UNREFERENCED_PARAMETER( hInstance );
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( nCmdShow );

    argc = 0;
    memset( &argv, 0, sizeof(argv) );

    CmdLine = lpCmdLine;
    if( CmdLine )
        while( *CmdLine && argc < MAX_ARGUMENTS )
        {
            while( ' ' == *CmdLine )
                CmdLine++;
            if( *CmdLine )
            {
                quote = ( '"' == *CmdLine );
                if( quote )
                {
                    CmdLine++;
                    Command = CmdLine;
                    while( *CmdLine && ( *CmdLine != '"' ) )
                        CmdLine++;
                }
                else
                {
                    Command = CmdLine;
                    while( *CmdLine && *CmdLine != ' ' && *CmdLine != '"' )
                        CmdLine++;
                };
                size = (char *)CmdLine - (char *)Command;
                argv[argc] = (LPTSTR)LocalAlloc( LPTR, size + sizeof(TCHAR) );
                if( argv[argc] )
                    memcpy( argv[argc], Command, size );
                argc++;
                if( quote && '"' == *CmdLine )
                    CmdLine++;
            };
        };

    result = main( argc, argv );

    while( argc > 0 )
        LocalFree( (HLOCAL)argv[--argc] );

    return result;
};

void __cdecl xmainCRTStartup( void )
{
    LPTSTR CmdLine;
    STARTUPINFO StartupInfo;

    CmdLine = GetCommandLine();
    if( CmdLine )
    {
        if( '"' == *CmdLine )
        {
            CmdLine++;
            while( *CmdLine && *CmdLine != '"' )
                CmdLine++;
            if( '"' == *CmdLine )
                CmdLine++;
        }
        else
            while( *CmdLine && *CmdLine != ' ' )
                CmdLine++;
        while( ' ' == *CmdLine )
            CmdLine++;
    };

    memset( &StartupInfo, 0, sizeof(STARTUPINFO) );
    StartupInfo.cb = sizeof(STARTUPINFO);
    GetStartupInfo( &StartupInfo );

    ExitProcess( 
        xWinMain( GetModuleHandle( NULL ), NULL, CmdLine,
            StartupInfo.dwFlags & STARTF_USESHOWWINDOW ?
            StartupInfo.wShowWindow : SW_SHOWNORMAL ) );
};

/* THE END */
