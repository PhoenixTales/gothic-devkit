/*++

Module Name:

    ztex2dds.c

Abstract:

    Simple ZTEX to DDS File Converter for Windows.

Author:

    Nico Bendlin <nicode@gmx.net>

Revision History:

    2005-04-25  Final/reviewed release (1.0)
    2005-04-20  First public release (alpha)

--*/

#define WIN32_LEAN_AND_MEAN
#define NONAMELESSUNION
#include <windows.h>
#include <ddraw.h>
#include "ztex.h"

/*//////////////////////////////////////////////////////////////////////////////
// Return Code
*/

#define ZTEX2DDS_ERROR_NONE   0 /* No Error                  */
#define ZTEX2DDS_ERROR_ARGS   1 /* Invalid Params / Syntax   */
#define ZTEX2DDS_ERROR_OPEN   2 /* Failed to Open Input      */
#define ZTEX2DDS_ERROR_READ   4 /* Failed to Read Input      */
#define ZTEX2DDS_ERROR_CREATE 5 /* Failed to Create Output   */
#define ZTEX2DDS_ERROR_WRITE  6 /* Failed to Write Output    */
#define ZTEX2DDS_ERROR_FORMAT 7 /* Invalid Input File Format */

/*//////////////////////////////////////////////////////////////////////////////
// Global Vars
*/

static HANDLE g_StdInput;   /* STD_INPUT_HANDLE */
static HANDLE g_StdOutput;  /* STD_OUTPUT_HANDLE */
static HANDLE g_StdError;   /* STD_ERROR_HANDLE */

static BOOL g_OptionSilent;  /* FALSE */
static BOOL g_OptionStdIn;   /* FALSE */
static BOOL g_OptionStdOut;  /* FALSE */

static BOOL g_OptionForceARGB;  /* FALSE */
static BOOL g_OptionHackAtiP8;  /* FALSE */

static TCHAR g_TEX_Filename[MAX_PATH];
static TCHAR g_DDS_Filename[MAX_PATH+5];

/*//////////////////////////////////////////////////////////////////////////////
// Utils/Stuff
*/

#ifndef max
#define max(a, b)   (((a) > (b)) ? (a) : (b)) 
#endif

void Write( HANDLE Console, LPCTSTR Text )
{
    DWORD Written;
    if ( g_OptionSilent )
        return;
    WriteFile( Console, Text, lstrlen(Text), &Written, NULL );
}

void WriteStdOut( LPCTSTR Text )
{
    if( g_OptionStdOut )
        return;
    Write( g_StdOutput, Text );
}

void WriteStdErr( LPCTSTR Text )
{
    if ( g_OptionSilent )
        return;
    Write( g_StdError, Text );
}

void WriteVersion( void )
{
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("ZTEX2DDS Converter, Version 1.0\n") );
    WriteStdOut( TEXT("Copyright (c) 2005 Nico Bendlin\n") );
};

void WriteHelp( void )
{
    WriteVersion();
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("Usage:\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  ztex2dds [options] [ztexfile] [ddsfile]\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("Options:\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  -h --help     Show this help screen\n") );
    WriteStdOut( TEXT("  -i --stdin    Use stdin as ztexfile\n") );
    WriteStdOut( TEXT("  -o --stdout   Use stdout as ddsfile\n") );
    WriteStdOut( TEXT("  -q --shutup   Suppress all messages\n") );
    WriteStdOut( TEXT("  -v --version  Copyright and version\n") );
    WriteStdOut( TEXT("\n") );
    WriteStdOut( TEXT("  --force-argb  Convert uncommon formats (e.g. BGRA) to ARGB\n") );
    WriteStdOut( TEXT("  --hack-atip8  FourCC 'P8  ' for ATI's 'The Compressonator'\n") );
    WriteStdOut( TEXT("\n") );
};

/*//////////////////////////////////////////////////////////////////////////////
// Converter
*/

BOOL IsPowerOfTwo( unsigned long x )
{
    if( x == 0)
        return FALSE;
    while( (x & 1) == 0 )
        x >>= 1;
    return ( 1 == x );
};

/*FIXME: Scanline Alignment */
DWORD GetMipmapSize( unsigned long format, unsigned long width, unsigned long height, int level )
{
    unsigned long x;
    unsigned long y;
    int i;

    x = max( 1, width );
    y = max( 1, height );
    for( i = 0; i < level; i++ )
    {
        if( x > 1 )
            x >>= 1;
        if( y > 1 )
            y >>= 1;
    }

    switch( format )
    {
    case ZTEXFMT_B8G8R8A8: 
    case ZTEXFMT_R8G8B8A8:
    case ZTEXFMT_A8B8G8R8:
    case ZTEXFMT_A8R8G8B8:
        return x * y * 4;
    case ZTEXFMT_B8G8R8:
    case ZTEXFMT_R8G8B8:
        return x * y * 3;
    case ZTEXFMT_A4R4G4B4:
    case ZTEXFMT_A1R5G5B5:
    case ZTEXFMT_R5G6B5:
        return x * y * 2;
    case ZTEXFMT_P8:
        return x * y;
    case ZTEXFMT_DXT1:
        return max( 1, x / 4 ) * max( 1, y / 4 ) * 8;
    case ZTEXFMT_DXT2:
    case ZTEXFMT_DXT3:
    case ZTEXFMT_DXT4:
    case ZTEXFMT_DXT5:
        return max( 1, x / 4 ) * max( 1, y / 4 ) * 16;
    default:
        return 0;
    };
};

int ConvertZTEX2DDS( HANDLE ztex, HANDLE dds )
{
    ZTEX_FILE_HEADER ZTexHeader;
    DWORD BytesRead;
    DWORD DdsMagic;
    DWORD BytesWritten;
    DDSURFACEDESC2 DdsHeader;
    int MipmapCount;
    int MipmapLevel;
    int i;
    RGBQUAD palentry;
    DWORD BufferSize;
    LPBYTE Buffer;
    DWORD MipmapSize;
    LPBYTE Mipmap;
    RGBQUAD * Pixel32;
    RGBTRIPLE * Pixel24;
    BYTE ColorTemp;

    /* 'ZTEX' */
    if( !ReadFile( ztex, &ZTexHeader, sizeof(ZTexHeader), &BytesRead, NULL ) ||
        BytesRead != sizeof(ZTexHeader) )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to read input (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_READ;
    };
    if( ZTexHeader.Signature != ZTEX_FILE_SIGNATURE ||
        ZTexHeader.Version != ZTEX_FILE_VERSION_0 ||
        ZTexHeader.TexInfo.Format > ZTEXFMT_DXT5 )
    {
        WriteStdErr( TEXT("ztex2dds: Unsupported file format (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_FORMAT;
    };

    /* 'DDS ' */
    DdsMagic = MAKEFOURCC( 'D', 'D', 'S', ' ' );
    if( !WriteFile( dds, &DdsMagic, sizeof(DdsMagic), &BytesWritten, NULL ) ||
        BytesWritten != sizeof(DdsMagic) )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to write output (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_WRITE;
    };
    /* DDSURFACEDESC2 */
    memset( &DdsHeader, 0, sizeof(DdsHeader) );
    DdsHeader.dwSize = sizeof(DDSURFACEDESC2);
    DdsHeader.dwFlags = DDSD_WIDTH | DDSD_HEIGHT | DDSD_PIXELFORMAT | DDSD_CAPS;
    DdsHeader.ddsCaps.dwCaps = DDSCAPS_TEXTURE;
    DdsHeader.dwHeight = ZTexHeader.TexInfo.Height;
    DdsHeader.dwWidth = ZTexHeader.TexInfo.Width;
    if( ZTexHeader.TexInfo.Format <= ZTEXFMT_P8 )
    {
        DdsHeader.dwFlags |= DDSD_PITCH;
        DdsHeader.u1.lPitch =
            GetMipmapSize( ZTexHeader.TexInfo.Format,  DdsHeader.dwWidth, 1, 0 );
    }
    else
    {
        DdsHeader.dwFlags |= DDSD_LINEARSIZE;
        DdsHeader.u1.dwLinearSize =
            GetMipmapSize( ZTexHeader.TexInfo.Format,  DdsHeader.dwWidth, DdsHeader.dwHeight, 0 );
    };
    if( ZTexHeader.TexInfo.MipMaps > 1 )
    {
        DdsHeader.dwFlags |= DDSD_MIPMAPCOUNT;
        DdsHeader.ddsCaps.dwCaps |= DDSCAPS_MIPMAP | DDSCAPS_COMPLEX;
        DdsHeader.u2.dwMipMapCount = ZTexHeader.TexInfo.MipMaps;
    };
    DdsHeader.u4.ddpfPixelFormat.dwSize = sizeof(DDPIXELFORMAT);
    switch( ZTexHeader.TexInfo.Format )
    {
    case ZTEXFMT_B8G8R8A8: 
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 32;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x00FF0000;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0xFF000000;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0x000000FF;
        break;
    case ZTEXFMT_R8G8B8A8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 32;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0xFF000000;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x00FF0000;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0x000000FF;
        break;
    case ZTEXFMT_A8B8G8R8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC             = D3DFMT_A8B8G8R8; /* 32 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 32;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x000000FF;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x00FF0000;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0xFF000000;
        break;
    case ZTEXFMT_A8R8G8B8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC             = D3DFMT_A8R8G8B8; /* 21 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 32;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x00FF0000;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x000000FF;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0xFF000000;
        break;
    case ZTEXFMT_B8G8R8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags          = DDPF_RGB;
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount = 24;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask    = 0x000000FF;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask    = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask    = 0x00FF0000;
        break;
    case ZTEXFMT_R8G8B8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags          = DDPF_RGB;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC         = D3DFMT_R8G8B8; /* 20 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount = 24;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask    = 0x00FF0000;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask    = 0x0000FF00;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask    = 0x000000FF;
        break;
    case ZTEXFMT_A4R4G4B4:
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC             = D3DFMT_A4R4G4B4; /* 26 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 16;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x00000F00;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x000000F0;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x0000000F;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0x0000F000;
        break;
    case ZTEXFMT_A1R5G5B5:
        DdsHeader.u4.ddpfPixelFormat.dwFlags              = DDPF_RGB | DDPF_ALPHAPIXELS;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC             = D3DFMT_A1R5G5B5; /* 25 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount     = 16;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x00007C00;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x000003E0;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x0000001F;
        DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0x00008000;
        break;
    case ZTEXFMT_R5G6B5:
        DdsHeader.u4.ddpfPixelFormat.dwFlags          = DDPF_RGB; 
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC         = D3DFMT_R5G6B5; /* 23 */
        DdsHeader.u4.ddpfPixelFormat.u1.dwRGBBitCount = 16;
        DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask    = 0x0000F800;
        DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask    = 0x000007E0;
        DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask    = 0x0000001F;
        break;
    case ZTEXFMT_P8:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_PALETTEINDEXED8;
    /*  DdsHeader.u4.ddpfPixelFormat.dwFourCC = D3DFMT_P8; /* 41 */
        if( g_OptionHackAtiP8 )
            DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC( 'P', '8', ' ', ' ' );  
        break;
    case ZTEXFMT_DXT1:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
        DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC('D', 'X', 'T', '1');
        break;
    case ZTEXFMT_DXT2:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
        DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC('D', 'X', 'T', '2');
        break;
    case ZTEXFMT_DXT3:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
        DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC('D', 'X', 'T', '3');
        break;
    case ZTEXFMT_DXT4:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
        DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC('D', 'X', 'T', '4');
        break;
    case ZTEXFMT_DXT5:
        DdsHeader.u4.ddpfPixelFormat.dwFlags  = DDPF_FOURCC;
        DdsHeader.u4.ddpfPixelFormat.dwFourCC = MAKEFOURCC('D', 'X', 'T', '5');
        break;
    };
    if( g_OptionForceARGB )
    {
        switch( ZTexHeader.TexInfo.Format )
        {
        case ZTEXFMT_B8G8R8A8: 
        case ZTEXFMT_R8G8B8A8:
        case ZTEXFMT_A8B8G8R8:
            DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask        = 0x00FF0000;
            DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask        = 0x0000FF00;
            DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask        = 0x000000FF;
            DdsHeader.u4.ddpfPixelFormat.u5.dwRGBAlphaBitMask = 0xFF000000;
            break;
        case ZTEXFMT_B8G8R8:
            DdsHeader.u4.ddpfPixelFormat.u2.dwRBitMask    = 0x00FF0000;
            DdsHeader.u4.ddpfPixelFormat.u3.dwGBitMask    = 0x0000FF00;
            DdsHeader.u4.ddpfPixelFormat.u4.dwBBitMask    = 0x000000FF;
            break;
        default:
            break;
        };
    };
    if( !WriteFile( dds, &DdsHeader, sizeof(DdsHeader), &BytesWritten, NULL ) ||
        BytesWritten != sizeof(DdsHeader) )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to write output (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_WRITE;
    };
    /* Palette */
    if( ZTEXFMT_P8 == ZTexHeader.TexInfo.Format )
    {
        for( i = 0; i < ZTEX_PAL_ENTRIES; i++ )
        {
            palentry.rgbReserved = 0x00;
            if( !ReadFile( ztex, &palentry, sizeof(ZTEX_PAL_ENTRY), &BytesRead, NULL ) ||
                BytesRead != sizeof(ZTEX_PAL_ENTRY) )
            {
                WriteStdErr( TEXT("ztex2dds: Failed to read input (") );
                WriteStdErr( g_TEX_Filename );
                WriteStdErr( TEXT(").\n") );
                return ZTEX2DDS_ERROR_READ;
            };
            if( !WriteFile( dds, &palentry, sizeof(RGBQUAD), &BytesWritten, NULL ) ||
                BytesWritten != sizeof(RGBQUAD) )
            {
                WriteStdErr( TEXT("ztex2dds: Failed to write output (") );
                WriteStdErr( g_DDS_Filename );
                WriteStdErr( TEXT(").\n") );
                return ZTEX2DDS_ERROR_WRITE;
            };
        }
    };
    /* Mipmaps */
    MipmapCount = max( 1, ZTexHeader.TexInfo.MipMaps );
    BufferSize = 0;
    for( MipmapLevel = 0; MipmapLevel < MipmapCount; MipmapLevel++ )
        BufferSize += GetMipmapSize( ZTexHeader.TexInfo.Format, 
            ZTexHeader.TexInfo.Width, ZTexHeader.TexInfo.Height, MipmapLevel );
    Buffer = (LPBYTE)LocalAlloc( LPTR, BufferSize );
    if( !Buffer )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to alocate memory (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_READ;
    };
    if( !ReadFile( ztex, Buffer, BufferSize, &BytesRead, NULL ) ||
        BytesRead != BufferSize )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to read input (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        LocalFree( (HLOCAL)Buffer );
        return ZTEX2DDS_ERROR_READ;
    };
    Mipmap = Buffer + BufferSize;
    for( MipmapLevel = 0; MipmapLevel < MipmapCount; MipmapLevel++ )
    {
        MipmapSize = GetMipmapSize( ZTexHeader.TexInfo.Format, 
            ZTexHeader.TexInfo.Width, ZTexHeader.TexInfo.Height, MipmapLevel );
        Mipmap -= MipmapSize;
        if( g_OptionForceARGB )
        {
            Pixel32 = (RGBQUAD *)Mipmap;
            Pixel24 = (RGBTRIPLE *)Mipmap;
            switch( ZTexHeader.TexInfo.Format )
            {
            case ZTEXFMT_B8G8R8A8:
                for( i = 0; i < (int)MipmapSize / 4; i++ )
                {
                    ColorTemp            = Pixel32->rgbReserved;
                    Pixel32->rgbReserved = Pixel32->rgbBlue;
                    Pixel32->rgbBlue     = ColorTemp;
                    ColorTemp            = Pixel32->rgbRed;
                    Pixel32->rgbRed      = Pixel32->rgbGreen;
                    Pixel32->rgbGreen    = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_R8G8B8A8:
                for( i = 0; i < (int)MipmapSize / 4; i++ )
                {
                    ColorTemp            = Pixel32->rgbBlue;
                    Pixel32->rgbBlue     = Pixel32->rgbGreen;
                    Pixel32->rgbGreen    = Pixel32->rgbRed;
                    Pixel32->rgbRed      = Pixel32->rgbReserved;
                    Pixel32->rgbReserved = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_A8B8G8R8:
                for( i = 0; i < (int)MipmapSize / 4; i++ )
                {
                    ColorTemp        = Pixel32->rgbBlue;
                    Pixel32->rgbBlue = Pixel32->rgbRed;
                    Pixel32->rgbRed  = ColorTemp;
                    Pixel32++;
                };
                break;
            case ZTEXFMT_B8G8R8:
                for( i = 0; i < (int)MipmapSize / 3; i++ )
                {
                    ColorTemp         = Pixel24->rgbtBlue;
                    Pixel24->rgbtBlue = Pixel24->rgbtRed;
                    Pixel24->rgbtRed  = ColorTemp;
                    Pixel24++;
                };
                break;
            default:
                break;
            };
        };
        if( !WriteFile( dds, Mipmap, MipmapSize, &BytesWritten, NULL ) ||
            BytesWritten != MipmapSize )
        {
            WriteStdErr( TEXT("ztex2dds: Failed to write output (") );
            WriteStdErr( g_DDS_Filename );
            WriteStdErr( TEXT(").\n") );
            LocalFree( (HLOCAL)Buffer );
            return ZTEX2DDS_ERROR_WRITE;
        };
    };
    LocalFree( (HLOCAL)Buffer );

    return ZTEX2DDS_ERROR_NONE;
};

/*//////////////////////////////////////////////////////////////////////////////
// Entry Point
*/

int __cdecl main( int argc, LPTSTR argv[ ] )
{
    int i;
    int len;
    TCHAR foo[2];
    LPTSTR opt;
    HANDLE ztex;
    HANDLE dds;
    int result;

    g_StdInput = GetStdHandle( STD_INPUT_HANDLE );
    g_StdOutput = GetStdHandle( STD_OUTPUT_HANDLE );
    g_StdError = GetStdHandle( STD_ERROR_HANDLE );
    if( argc <= 0 )
    {
        WriteHelp();
        return ZTEX2DDS_ERROR_NONE;
    }
    g_OptionSilent = FALSE;
    g_OptionStdIn  = FALSE;
    g_OptionStdOut = FALSE;
    g_OptionForceARGB = FALSE;
    g_OptionHackAtiP8 = FALSE;
    memset( &g_TEX_Filename, 0, sizeof(g_TEX_Filename) );
    memset( &g_DDS_Filename, 0, sizeof(g_DDS_Filename) );
    for( i = 0; i < argc; i++ )
    {
        opt = argv[i];
        if( !opt || !*opt || ( *opt != '-' && *opt != '/' ) )
            break;
        if( !lstrcmpi( opt, TEXT("--") ) )
        {
            i++;
            break;
        }
        opt++;
        if( '-' == *opt )
        {
            opt++;
            if( !lstrcmpi( opt, TEXT("help") ) )
            {
                WriteHelp();
                return ZTEX2DDS_ERROR_NONE;
            }
            if( !lstrcmpi( opt, TEXT("version") ) )
            {
                WriteVersion();
                return ZTEX2DDS_ERROR_NONE;
            }
            if( !lstrcmpi( opt, TEXT("stdin") ) )
                g_OptionStdIn = TRUE;
            else if( !lstrcmpi( opt, TEXT("stdout") ) )
                g_OptionStdOut = TRUE;
            else if( !lstrcmpi( opt, TEXT("shutup") ) )
                g_OptionSilent = TRUE;
            else if( !lstrcmpi( opt, TEXT("force-argb") ) )
                g_OptionForceARGB = TRUE;
            else if( !lstrcmpi( opt, TEXT("hack-atip8") ) )
                g_OptionHackAtiP8 = TRUE;
            else
            {
                WriteStdErr( TEXT("ztex2dds: Invalid option (") );
                WriteStdErr( argv[i] );
                WriteStdErr( TEXT(").\n") );
                return ZTEX2DDS_ERROR_ARGS;
            }
        }
        else
        {
            while( *opt )
            {
                switch( *opt )
                {
                case 'i':
                    g_OptionStdIn = TRUE;
                    break;
                case 'o':
                    g_OptionStdOut = TRUE;
                    break;
                case 'q':
                    g_OptionSilent = TRUE;
                    break;
                case 'h':
                case 'H':
                case '?':
                    WriteHelp();
                    return ZTEX2DDS_ERROR_NONE;
                case 'v':
                case 'V':
                    WriteVersion();
                    return ZTEX2DDS_ERROR_NONE;
                default:
                    WriteStdErr( TEXT("ztex2dds: Invalid option (") );
                    foo[0] = *opt;
                    foo[1] = '\0';
                    WriteStdErr( foo );
                    WriteStdErr( TEXT(").\n") );
                    return ZTEX2DDS_ERROR_ARGS;
                };
                opt++;
            };
        };
    };

    if( g_OptionStdIn )
    {
        if( g_OptionStdOut )
        {
            if( i < argc )
            {
                WriteStdErr( TEXT("ztex2dds: Too many arguments (") );
                while( i < argc )
                {
                    WriteStdErr( argv[ i ] );
                    i++;
                    if( i < argc )
                        WriteStdErr( TEXT(" ") );
                };
                WriteStdErr( TEXT(").\n") );
                return ZTEX2DDS_ERROR_ARGS;
            };
        }
        else
        {
            if( i >= argc )
            {
                WriteStdErr( TEXT("ztex2dds: Missing argument (ddsfile).\n") );
                return ZTEX2DDS_ERROR_ARGS;
            };
            lstrcpyn( g_DDS_Filename, argv[i], MAX_PATH );
        };
    }
    else
    {
        if( i >= argc )
        {
            WriteStdErr( TEXT("ztex2dds: Missing argument (ztexfile).\n") );
            return ZTEX2DDS_ERROR_ARGS;
        };
        lstrcpyn( g_TEX_Filename, argv[i], MAX_PATH );
        i++;
        if( !g_OptionStdOut && (i < argc) )
        {
            lstrcpyn( g_DDS_Filename, argv[i], MAX_PATH );
            i++;
        }
        else
        {
            lstrcpyn( g_DDS_Filename, g_TEX_Filename, MAX_PATH );
            len = lstrlen( g_DDS_Filename );
            if( len > 6 && !lstrcmpi( &g_DDS_Filename[ len - 6 ], TEXT("-C.TEX") ) )
                lstrcpyn( &g_DDS_Filename[ len - 6 ], TEXT(".DDS"), 5 );
            else if( len > 4 && !lstrcmpi( &g_DDS_Filename[ len - 4 ], TEXT(".TEX") ) )
                lstrcpyn( &g_DDS_Filename[ len - 4 ], TEXT(".DDS"), 5 );
            else
                lstrcpyn( &g_DDS_Filename[ len ], TEXT(".DDS"), 5 );
        };
        if( i < argc )
        {
            WriteStdErr( TEXT("ztex2dds: Too many arguments.\n") );
            return ZTEX2DDS_ERROR_ARGS;
        };
    };

    if( g_OptionStdIn )
    {
        lstrcpyn( g_TEX_Filename, TEXT("stdin"), MAX_PATH );
        ztex = g_StdInput;
    }
    else
        ztex = CreateFile( g_TEX_Filename, GENERIC_READ, FILE_SHARE_READ, NULL,
            OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
    if( !ztex || (INVALID_HANDLE_VALUE == ztex) )
    {
        WriteStdErr( TEXT("ztex2dds: Failed to open (") );
        WriteStdErr( g_TEX_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_OPEN;
    }
    if( g_OptionStdOut )
    {
        lstrcpyn( g_DDS_Filename, TEXT("stdout"), MAX_PATH );
        dds = g_StdOutput;
    }
    else
        dds = CreateFile( g_DDS_Filename, GENERIC_WRITE, FILE_SHARE_READ, NULL,
            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
    if( !dds || (INVALID_HANDLE_VALUE == dds) )
    {
        if( !g_OptionStdIn )
            CloseHandle(ztex);
        WriteStdErr( TEXT("ztex2dds: Failed to create (") );
        WriteStdErr( g_DDS_Filename );
        WriteStdErr( TEXT(").\n") );
        return ZTEX2DDS_ERROR_CREATE;
    }

    result = ConvertZTEX2DDS( ztex, dds );

    if( !g_OptionStdIn )
        CloseHandle( ztex );
    if( !g_OptionStdOut )
    {
        CloseHandle( dds );
        if( result != ZTEX2DDS_ERROR_NONE )
            DeleteFile( g_DDS_Filename );
    }

    return result;
};

int __stdcall xWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow )
{
    #define MAX_ARGUMENTS ( 0x100 )

    int argc;
    int result;
    BOOL quote;
    SIZE_T size;
    LPTSTR argv[ MAX_ARGUMENTS+1 ];
    LPTSTR CmdLine;
    LPTSTR Command;

    UNREFERENCED_PARAMETER( hInstance );
    UNREFERENCED_PARAMETER( hPrevInstance );
    UNREFERENCED_PARAMETER( nCmdShow );

    argc = 0;
    memset( &argv, 0, sizeof(argv) );

    CmdLine = lpCmdLine;
    if( CmdLine )
        while( *CmdLine && argc < MAX_ARGUMENTS )
        {
            while( ' ' == *CmdLine )
                CmdLine++;
            if( *CmdLine )
            {
                quote = ( '"' == *CmdLine );
                if( quote )
                {
                    CmdLine++;
                    Command = CmdLine;
                    while( *CmdLine && ( *CmdLine != '"' ) )
                        CmdLine++;
                }
                else
                {
                    Command = CmdLine;
                    while( *CmdLine && *CmdLine != ' ' && *CmdLine != '"' )
                        CmdLine++;
                };
                size = (char *)CmdLine - (char *)Command;
                argv[argc] = (LPTSTR)LocalAlloc( LPTR, size + sizeof(TCHAR) );
                if( argv[argc] )
                    memcpy( argv[argc], Command, size );
                argc++;
                if( quote && '"' == *CmdLine )
                    CmdLine++;
            };
        };

    result = main( argc, argv );

    while( argc > 0 )
        LocalFree( (HLOCAL)argv[--argc] );

    return result;
};

void __cdecl xmainCRTStartup( void )
{
    LPTSTR CmdLine;
    STARTUPINFO StartupInfo;

    CmdLine = GetCommandLine();
    if( CmdLine )
    {
        if( '"' == *CmdLine )
        {
            CmdLine++;
            while( *CmdLine && *CmdLine != '"' )
                CmdLine++;
            if( '"' == *CmdLine )
                CmdLine++;
        }
        else
            while( *CmdLine && *CmdLine != ' ' )
                CmdLine++;
        while( ' ' == *CmdLine )
            CmdLine++;
    };

    memset( &StartupInfo, 0, sizeof(STARTUPINFO) );
    StartupInfo.cb = sizeof(STARTUPINFO);
    GetStartupInfo( &StartupInfo );

    ExitProcess( 
        xWinMain( GetModuleHandle( NULL ), NULL, CmdLine,
            StartupInfo.dwFlags & STARTF_USESHOWWINDOW ?
            StartupInfo.wShowWindow : SW_SHOWNORMAL ) );
};

/* THE END */
